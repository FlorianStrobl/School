Lernraum-berlin: **Informatik LK 12: Datenbanken**

[Wikipedia: Entity-Relationship-Modell](https://www.wikiwand.com/de/Entity-Relationship-Modell "Entity-Relationship-Modell | Wikiwand")

[Entity-Relationship-Modell (ER-Modell / ERM) | Datenmodellierung Grundlagen](https://www.datenbanken-verstehen.de/datenmodellierung/entity-relationship-modell/ "Entity-Relationship-Modell (ER-Modell / ERM) | Datenmodellierung Grundlagen")

[Entity Relationship Diagram (ERD) - What is an ER Diagram?](https://www.smartdraw.com/entity-relationship-diagram/#ERDtypes "Entity Relationship Diagram (ERD) - What is an ER Diagram?")

[Attribute in einer Entität - Enitity - Relationship -...](https://www.datenbanken-verstehen.de/datenmodellierung/attribute-datenbank/ "Attribute in einer Entität - Enitity - Relationship - Modell | Datenmodellierung Grundlagen")
